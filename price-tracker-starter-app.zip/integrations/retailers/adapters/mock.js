export const id = "mock";
export async function search(query) {
  const basePrice = query.length * 0.5 + 4.99;
  return [
    { title: `Mock ${query} - Value Pack`, price: Number((basePrice).toFixed(2)),
      url: "https://example.com/mock/value-pack", image: "https://via.placeholder.com/300", storeId: id },
    { title: `Mock ${query} - Premium`, price: Number((basePrice + 3.5).toFixed(2)),
      url: "https://example.com/mock/premium", image: "https://via.placeholder.com/300", storeId: id }
  ];
}
