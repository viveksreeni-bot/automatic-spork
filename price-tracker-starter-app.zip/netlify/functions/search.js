import { search as mock, id as mockId } from "../../integrations/retailers/adapters/mock.js";

export async function handler(event, context) {
  const params = new URLSearchParams(event.rawQuery || "");
  const q = params.get("q") || "diapers";
  const stores = (params.get("stores") || "mock").split(",").map(s => s.trim()).filter(Boolean);

  const adapters = new Map([[mockId, mock]]);
  const tasks = stores.map(s => adapters.get(s)?.(q).catch(() => []) || []);
  const lists = await Promise.all(tasks);
  const results = lists.flat();
  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ query: q, stores, count: results.length, results })
  };
}
